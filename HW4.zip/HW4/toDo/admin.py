from django.contrib import admin
from .models import ToDos

# Register your models here.
admin.site.register(ToDos)
